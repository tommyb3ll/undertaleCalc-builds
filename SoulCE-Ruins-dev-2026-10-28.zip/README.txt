SoulCE calculator test build (basement dialogue hardware test, 2026-10-28)

Transfer all 23 calculator files in this folder: SOULCE.8xp and
SOULDAT0 through SOULDATL.8xv (22 data appvars). Keep both the
program and data appvars in Archive. CE C libraries (clibs.8xg) must already
be installed. Launch SOULCE with your existing assembly-capable shell.

Before transferring, back up any save you want to keep, then delete all old
SOULDAT* appvars and SOULSAVE from the calculator. Old saves may refer to
different room IDs or story variables. Transfer the entire new set together;
mixing pack versions can make the program fail to load.

Controls: arrows move; [2nd]/[enter] confirm; [alpha]/[del] cancel or skip
text (hold to run); [mode] opens the menu; [clear] quits to the title.
On the title screen, [mode] opens the debug room/battle list.

This is a CEmu-tested development build for calculator testing after a memory wipe.
It includes the corrected house stair hall, the basement mechanics, generated
first-play basement and Ruins-exit dialogue, Toriel's battle, and the exit fade.
The generated pack has 22 data appvars. CEmu checks pass for the natural stair
route, early return, dialogue route, Toriel spare/kill outcomes and tested exit
branches. The project owner has played this build on a physical TI-84 Plus CE.

Persistent-memory dialogue selection, exact path points, text
presentation/timing parity, and the post-exit title card remain incomplete.

MANIFEST.json records the SHA-256 hash and size of every transferred file.
